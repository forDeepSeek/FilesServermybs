Brawl Stars V48 MOD! Client by @SpeigenGit

Discord link : https://discord.gg/kcVzmSTP58

ANDROID (GOOGLE DRIVE) : https://drive.google.com/file/d/1BT2ildyXKWIsVpYccME8sXicmvYJR4zv/view?usp=drivesdk

Server ZIP: https://codeload.github.com/LekmaDev/LSBS-V48/zip/refs/heads/main

## Requirements: ##
1. a brain...

## How to play LSBS: ##
1. download server and apk
2. install the apk
3. download pydroid (if you want to run from the phone)
4. open in pydroid Core.py located in the server folder
5. click on the run button
6. now open the game and play

## Change the ip address and port (if needed) in libprojectbsds.config.so located in the lib folder of the apk ##

![lsbsv48](https://cdn.discordapp.com/attachments/1040608064681803827/1090261450095874058/Screenshot_2023-03-28-16-09-21-822_com.lsbs.v48888.jpg)
